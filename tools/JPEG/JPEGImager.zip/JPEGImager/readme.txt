JPEG Imager 2.1.2
=================
Copyright (C) 1998-2004 V-Methods Software

A simple, fast, easy-to-use, interactive image compressor.
Use it to optimize the quality and file size of your images.

Release Date: January 23, 2004
Target OS:    Windows 98/Me/2000/XP

General Features

- Interactive compression to JPEG, PNG and GIF files. 
- Real-time preview of compressed images.
- Various compression controls.
- Synchronized Side By Side view (Original vs. Compressed).
- Handy tools for image scrolling and zooming.
- Basic image manipulation and enhancing operations such as Resample,
  Crop, Rotation, Gamma correction, Levels adjustment and so on.
- Image acquisition from scanners and digital cameras via TWAIN.
- Simple built-in batch processor and thumbnail generator.

JPEG Compressor Features

- High compression ratio with good picture quality.
- Separate quality controls for luminance and chrominance channels.
- Flexible subsampling setup (for chromatic components).
- Progressive encoding mode (greatly improved since v1.01).
- Selective extra-compression mode.
- Fit to File Size feature - automatic quality adjustment.
- Optional retention of application specific data (such as EXIF) 
  in APP1-15 marker segments.
- The ability to edit or automatically replace embedded JPEG file comment.
- Optional insertion of Restart Markers (integrity marks).

Latest changes

  Version 2.1.2.25
- Changes in the HSL correction tool: 
  - Added "Colorize" option (creates a monotone effect). 
  - Improved saturation control. 
- Fixed a bug with removing files in the File List box. 
- Minor tweaks/optimizations. 

  Version 2.1.1.23 (October 14, 2003) 
- Now it's not necessary to press the Compress button before saving an image. 
  When you click the Save button, the image is compressed automatically. 
- Fixed a bug with TWAIN operation on some scanners. 
- Added basic support for WIA interface (Windows Image Acquisition). 
- Some internal rearrangement; trivial fixes and improvements. 

  Version 2.1.0.19 (August 25, 2003)
- Added "Gaussian Blur" filter.
- Added "Unsharp Mask" filter.
- Added "Equalize Lightness" tool (advanced image processing). 
- Added an ability to change the physical resolution of an image.
- Added "Restore defaults" command (the Compress menu).
- Added "Detect settings" command (the Compress menu, JPEG only).
- Improved speed of the resampling and convolution filtering algorithms.
- Improved the file size optimization dialog (JPEG).
- Revised the alternate quantization tables (JPEG).
- Other minor fixes and improvements.

Known shortcomings

- The selective extra-compression still needs a little refinement.
- Transparency information (alpha channel) can only be stored 
  in TrueColor PNG files. It is not possible yet to save 
  transparent images in indexed (palette-based) PNG or GIF.
- The help file is incomplete.


Contact E-Mail: info@v-methods.com

Web: http://www.v-methods.com/ji/
     http://www.jpegimager.com/
